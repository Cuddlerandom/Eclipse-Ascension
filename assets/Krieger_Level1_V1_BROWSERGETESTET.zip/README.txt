ECLIPSE: ASCENSION - KRIEGER LEVEL 1
104 RGBA Frames, 16 Sheets, 160x160 px, Anker (80,144).
Keine Betäubung oder Tod fuer Nahkampfhelden.
Start: vorschau.html im Browser oeffnen.
Animations-FPS siehe manifest.json.
Originalkonzept nicht ueberschrieben.
Hinweis: Grafik-/Gameplay-Endfreigabe durch Hauptzentrale im echten Renderer offen.
