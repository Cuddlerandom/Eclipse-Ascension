# ECLIPSE: ASCENSION – Goblin-Plünderer V1.0 – Grafikstudio-Übergabe

**Status:** Künstlerischer Produktionskandidat, **nicht** technisch oder spielerisch freigegeben.

- **Lieferumfang:** 96 RGBA-PNG-Einzelbilder, 6 PNG-Sprite-Sheets, `manifest.json`.
- **Raster:** 128×128 px pro Einzelbild; Sheets 512×512 px (4 Frames × 4 Richtungen).
- **Reihenfolge:** unten, oben, links, rechts; pro Richtung Frames 0–3.
- **Anker:** (64,112) pro Einzelbild, Fussposition; zunächst zu prüfen.
- **Animationen:** idle, laufen, umschauen, dolchfuchteln, getroffen, sterben. Dolchfuchteln ist **nur optisch**, keine Angriffsfähigkeit.
- **Timing-Vorschläge:** siehe `manifest.json`; nicht final freigegeben.
- **Transparenz:** Alphakanal vorhanden; automatisierte Entfernung des Schachbretthintergrunds aus der Konzeptgrafik, **nicht** manuell validiert.
- **Design:** olivgrüner, kleiner buckliger Goblin, geflicktes Leder, zwei kleine Dolche, elementar neutral, Rauch-/Partikeltod.
- **Bekannte Mängel:** Das Quellmaterial ist eine gestaltete Konzepttafel, keine nativen Einzel-Originale. Maskenränder, visuelle Kohärenz, beide Dolche und Animationsfluss müssen geprüft werden; nicht als fertig freigeben.
- **Hauptzentrale:** Bitte zuerst Alpha/Kanten, Frame-Versatz und Animationsfluss im Browser prüfen; falls künstlerische Mängel bestehen, Grafikstudio zurückmelden. Erst dann ins GitHub-Gameplay übernehmen.
